#!/bin/sh
set -eu
cd "$(dirname "$0")"
echo DEVICE_NOT_TESTED
sha256sum -c SHA256SUMS
./har_generic > generic.log
./har_mobile > mobile.log
awk 'BEGIN{g=0;m=0}
  FNR==NR && $1=="DATA_PREDICT" {g++; a[g]=$0; next}
  $1=="DATA_PREDICT" {m++; if ($0 != a[m]) {print "LOGIT_MISMATCH", m; exit 1}}
  END {if (g!=2947 || m!=2947) {print "ROW_MISMATCH", g, m; exit 1} print "HAR_LOGITS_IDENTICAL", m}' generic.log mobile.log
./cartpole_generic > cartpole_generic.log
./cartpole_mobile > cartpole_mobile.log
awk 'BEGIN{g=0;m=0}
  FNR==NR && $1=="PREDICT" {g++; a[g]=$0; next}
  $1=="PREDICT" {m++; if ($0 != a[m]) {print "CARTPOLE_MISMATCH"; exit 1}}
  END {if (g!=1 || m!=1) exit 1; print "CARTPOLE_PREDICT_IDENTICAL"}' cartpole_generic.log cartpole_mobile.log
echo '--- bench har ---'
./bench_arm64 --task har
echo '--- bench cartpole ---'
./bench_arm64 --task cartpole
echo DEVICE_NOT_TESTED

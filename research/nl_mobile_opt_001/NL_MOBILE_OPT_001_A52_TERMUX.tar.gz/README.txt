NL-MOBILE-OPT-001 Android ARM64 API 26 bundle.
DEVICE_NOT_TESTED by the builder. This script must not be read as a device pass.
Unpack under Termux $HOME, then: sh run.sh
har_generic is the previous FULL path. har_mobile is --profile mobile-cpu.
FP64 row order is unchanged. NEON was not enabled.
UCI HAR features are the published test split with whitespace normalized.

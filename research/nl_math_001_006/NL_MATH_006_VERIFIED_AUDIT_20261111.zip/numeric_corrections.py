"""Research-only corrected mathematical oracles. No production runtime changes.

Exact-rational dot: real arithmetic oracle rounded once; NOT FP64 row-order.
"""
from fractions import Fraction
import math

class NumericError(ValueError):
    pass

def numbers(seq):
    if not isinstance(seq, (list, tuple)) or not seq:
        raise NumericError('nonempty list/tuple required')
    out=[]
    for v in seq:
        if type(v) not in (int, float): raise NumericError('unsupported type')
        try: f=float(v)
        except (ValueError, OverflowError): raise NumericError('nonrepresentable input') from None
        if not math.isfinite(f): raise NumericError('nonfinite input')
        out.append(f)
    return out

def real_dot(a, b):
    a, b = numbers(a), numbers(b)
    if len(a) != len(b): raise NumericError('shape mismatch')
    total=sum((Fraction.from_float(x)*Fraction.from_float(y) for x,y in zip(a,b)), Fraction())
    try: result=float(total)
    except OverflowError: raise NumericError('real dot not representable in FP64') from None
    if not math.isfinite(result): raise NumericError('nonfinite result')
    return result

def strict_fp64_dot(a, b):
    a, b = numbers(a), numbers(b)
    if len(a) != len(b): raise NumericError('shape mismatch')
    result=0.0
    for x,y in zip(a,b):
        term=x*y
        if not math.isfinite(term): raise NumericError('FP64 multiplication overflow')
        result+=term
        if not math.isfinite(result): raise NumericError('FP64 addition overflow')
    return result

def nll_stable(logits, target):
    z=numbers(logits)
    if type(target) is not int or target<0 or target>=len(z):
        raise NumericError('target index')
    m=max(z)
    # Underflowed exp(-inf)=0 is permitted internally; inputs are all finite.
    exps=math.fsum(math.exp(x-m) for x in z)
    leading=m-z[target]
    result=leading+math.log(exps)
    if not math.isfinite(result): raise NumericError('unrepresentable loss')
    return result

def layernorm_stable(x, gamma, beta, epsilon):
    x,g,b=numbers(x),numbers(gamma),numbers(beta)
    if len(x)!=len(g) or len(x)!=len(b): raise NumericError('shape mismatch')
    if type(epsilon) not in (int,float) or not math.isfinite(epsilon) or epsilon<=0:
        raise NumericError('epsilon')
    scale=max(map(abs,x))
    if scale==0: return tuple(b)
    y=[v/scale for v in x]
    mu=math.fsum(y)/len(y)
    variance=math.fsum((v-mu)**2 for v in y)/len(y)
    if variance==0: out=b
    else:
        rt=math.sqrt(variance); rte=math.sqrt(epsilon)
        if scale <= rte:
            factor=scale/math.hypot(scale*rt,rte)
            norms=[(v-mu)*factor for v in y]
        else:
            factor=math.hypot(rt,rte/scale)
            norms=[(v-mu)/factor for v in y]
        out=[v*gv+bv for v,gv,bv in zip(norms,g,b)]
    if not all(map(math.isfinite,out)): raise NumericError('nonfinite LayerNorm output')
    return tuple(out)

def attention_real_dot_tiny(q,k,v):
    if not q or len(q)!=len(k) or len(q)!=len(v): raise NumericError('sequence')
    q=[numbers(row) for row in q];k=[numbers(row) for row in k];v=[numbers(row) for row in v]
    d,dv=len(q[0]),len(v[0])
    if any(len(row)!=d for row in q+k) or any(len(row)!=dv for row in v):
        raise NumericError('shape')
    result=[]
    for i in range(len(q)):
        scores=[real_dot(q[i],k[j])/math.sqrt(d) for j in range(i+1)]
        m=max(scores); w=[math.exp(s-m) for s in scores]; den=math.fsum(w)
        row=[]
        for col in range(dv):
            terms=[w[j]*v[j][col] for j in range(i+1)]
            if not all(map(math.isfinite,terms)): raise NumericError('attention numerator overflow')
            value=math.fsum(terms)/den
            if not math.isfinite(value): raise NumericError('attention nonfinite')
            row.append(value)
        result.append(tuple(row))
    return tuple(result)

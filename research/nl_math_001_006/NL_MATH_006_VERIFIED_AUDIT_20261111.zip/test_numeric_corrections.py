import sys, math, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,str(Path(__file__).resolve().parent/'legacy_baseline'))
from numeric_corrections import NumericError, nll_stable, layernorm_stable, strict_fp64_dot, real_dot, attention_real_dot_tiny
import tensor_math

class NewBoundaryChecks(unittest.TestCase):
 def test_old_nll_failure_exposed(self):
  with self.assertRaises(ValueError): tensor_math.nll_target([1e308,-1e308],0)
 def test_corrected_nll(self): self.assertEqual(nll_stable([1e308,-1e308],0),0.)
 def test_nll_unrepresentable_rejected(self):
  with self.assertRaises(NumericError): nll_stable([1e308,-1e308],1)
 def test_nll_standard(self): self.assertAlmostEqual(nll_stable([0.,0.,0.],1),math.log(3.))
 def test_nll_label_validation(self):
  with self.assertRaises(NumericError): nll_stable([0.,1.],True)
 def test_old_dot_nonfinite_exposed(self): self.assertEqual(tensor_math.dot([1e200],[1e200]),math.inf)
 def test_strict_dot_rejects(self):
  with self.assertRaises(NumericError): strict_fp64_dot([1e200],[1e200])
 def test_strict_dot_normal(self): self.assertEqual(strict_fp64_dot([1.,2.],[3.,4.]),11.)
 def test_real_dot_cancellation(self): self.assertEqual(real_dot([1e200,1e200],[1e200,-1e200]),0.)
 def test_real_dot_out_of_range(self):
  with self.assertRaises(NumericError): real_dot([1e200],[1e200])
 def test_old_layernorm_overflow_exposed(self):
  with self.assertRaises(OverflowError): tensor_math.layernorm([1e200,-1e200],[1.,1.],[0.,0.],1e-5)
 def test_corrected_layernorm_huge(self): self.assertEqual(layernorm_stable([1e200,-1e200],[1,1],[0,0],1e-5),(1.,-1.))
 def test_corrected_layernorm_normal(self):
  a=layernorm_stable([2.,-2.],[1.,1.],[0.,0.],1e-5)
  self.assertAlmostEqual(a[0],2./math.sqrt(4.+1e-5));self.assertAlmostEqual(a[1],-2./math.sqrt(4.+1e-5))
 def test_corrected_layernorm_constant(self): self.assertEqual(layernorm_stable([4.,4.],[1.,1.],[3.,2.],1e-5),(3.,2.))
 def test_corrected_layernorm_tiny(self): self.assertTrue(all(map(math.isfinite,layernorm_stable([1e-200,-1e-200],[1,1],[0,0],1e-5))))
 def test_old_attention_nan_exposed(self):
  r=tensor_math.causal_attention_online([[1e200,1e200]],[[1e200,-1e200]],[[1.,2.]])
  self.assertTrue(all(math.isnan(t) for t in r[0]))
 def test_corrected_attention(self): self.assertEqual(attention_real_dot_tiny([[1e200,1e200]],[[1e200,-1e200]],[[1.,2.]]),((1.,2.),))
 def test_corrected_attention_causal(self):
  r=attention_real_dot_tiny([[1,0],[1,0]],[[1,0],[0,1]],[[1],[3]])
  self.assertEqual(r[0],(1.,));self.assertTrue(1.<r[1][0]<3.)
 def test_attention_shape_reject(self):
  with self.assertRaises(NumericError): attention_real_dot_tiny([[1,0]],[[1]],[[0]])
 def test_true_parameter_count(self):
  B,d,f,V,C=10,768,1824,4096,1024
  self.assertEqual((V+C)*d+2*d+B*(4*d*d+2*d*f+9*d+f),55_630_656)
 def test_kv_size(self): self.assertEqual(2*10*1024*768*2,31_457_280)
 def test_saturation_counterexample(self):
  w=100.;s=1./127.; q=127;decoded=s*q
  self.assertEqual(abs(w-decoded),99.)
  self.assertGreater(abs(w-decoded),s/2)

if __name__=='__main__': unittest.main()

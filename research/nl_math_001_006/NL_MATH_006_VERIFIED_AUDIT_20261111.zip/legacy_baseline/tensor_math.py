"""NL-MATH-002 deterministic FP64 reference formulas (not accelerated .nir kernels).

Used to falsify attempted compiler/operator implementations. No dependencies.
"""
import math


def _finite(values):
    if any(not math.isfinite(x) for x in values):
        raise ValueError('only finite scalars allowed')


def dot(u, v):
    if not u or len(u) != len(v):
        raise ValueError('dot shape')
    _finite(u); _finite(v)
    acc = 0.0
    for a, b in zip(u, v):
        acc += a*b
    return acc


def logsumexp(values):
    if not values:
        raise ValueError('empty reduction')
    _finite(values)
    m = max(values)
    return m + math.log(sum(math.exp(x - m) for x in values))


def nll_target(logits, target):
    if not logits or type(target) is not int or not 0 <= target < len(logits):
        raise ValueError('invalid logits/target')
    return logsumexp([value - logits[target] for value in logits])


def greedy_token(logits):
    if not logits:
        raise ValueError('empty logits')
    _finite(logits)
    return max(range(len(logits)), key=lambda idx: logits[idx])  # earliest-ID tie


def stable_softmax(values):
    if not values:
        raise ValueError('empty softmax')
    _finite(values)
    m = max(values)
    w = [math.exp(v - m) for v in values]
    total = sum(w)
    return tuple(x/total for x in w)


def layernorm(x, gamma, beta, epsilon):
    if not x or len(x) != len(gamma) or len(x) != len(beta):
        raise ValueError('shape mismatch')
    if not isinstance(epsilon, (int,float)) or epsilon <= 0 or not math.isfinite(epsilon):
        raise ValueError('epsilon must be positive')
    _finite(x);_finite(gamma);_finite(beta)
    mean = sum(x)/len(x)
    variance = sum((v-mean)**2 for v in x)/len(x)
    scale = 1.0 / math.sqrt(variance + epsilon)
    return tuple((v-mean)*scale*g+b for v,g,b in zip(x,gamma,beta))


def matmul(a, b):
    if not a or not b or not a[0] or not b[0]:
        raise ValueError('empty matrices')
    n, inner, m = len(a), len(a[0]), len(b[0])
    if any(len(row)!=inner for row in a) or len(b)!=inner or any(len(row)!=m for row in b):
        raise ValueError('matrix shape mismatch')
    return tuple(tuple(dot(a[i],tuple(b[k][j] for k in range(inner)))
                       for j in range(m)) for i in range(n))


def causal_attention_reference(q, k, v):
    """Full O(T^2) attention, one head, row-by-row causal; no padding.
    The output is finite deterministic FP64 for tiny test sizes, not exact bits
    of optimized torch/BLAS/FlashAttention backends.
    """
    if not q or len(q)!=len(k) or len(k)!=len(v):
        raise ValueError('sequence mismatch')
    t=len(q)
    d=len(q[0]); dv=len(v[0])
    if d<1 or dv<1 or any(len(row)!=d for row in q+k) or any(len(row)!=dv for row in v):
        raise ValueError('dimension mismatch')
    result=[]
    for i in range(t):
        logits=[dot(q[i],k[j])/math.sqrt(d) for j in range(i+1)]
        p=stable_softmax(logits)
        result.append(tuple(sum(p[j]*v[j][h] for j in range(i+1)) for h in range(dv)))
    return tuple(result)


def causal_attention_online(q, k, v):
    """Online-softmax recurrence (real-arithmetic equivalent to full attention).
    Uses stable running maximum and denominator; different FP summation order.
    """
    if not q or len(q)!=len(k) or len(k)!=len(v):
        raise ValueError('sequence mismatch')
    t=len(q);d=len(q[0]);dv=len(v[0])
    if d<1 or dv<1 or any(len(row)!=d for row in q+k) or any(len(row)!=dv for row in v):
        raise ValueError('dimension mismatch')
    result=[]
    for i in range(t):
        maximum=float('-inf'); denominator=0.0; numerator=[0.0]*dv
        for j in range(i+1):
            score=dot(q[i],k[j])/math.sqrt(d)
            m_new=max(maximum,score)
            scale_old=0.0 if maximum == float('-inf') else math.exp(maximum-m_new)
            scale_new=math.exp(score-m_new)
            denominator=denominator*scale_old+scale_new
            numerator=[old*scale_old+scale_new*value for old,value in zip(numerator,v[j])]
            maximum=m_new
        result.append(tuple(x/denominator for x in numerator))
    return tuple(result)


def lora_forward(w0, a, b, x, alpha: float):
    """Vector y = W0*x + alpha/r * B*(A*x), purely real-formula FP64 oracle."""
    if not a or not b or not w0 or not x:
        raise ValueError('empty LoRA')
    r = len(a)
    d_in = len(x)
    d_out = len(w0)
    if any(len(row) != d_in for row in a+w0) or len(b)!=d_out or any(len(row)!=r for row in b):
        raise ValueError('invalid LoRA shapes')
    if r > min(d_in,d_out) or not math.isfinite(alpha):
        raise ValueError('invalid LoRA rank or alpha')
    u = [dot(row,x) for row in a]
    scale=alpha/r
    return tuple(dot(w,x)+scale*dot(bb,u) for w,bb in zip(w0,b))


def lora_gradients(a, b, x, upstream, alpha: float):
    """Analytical gradients dL/dA and dL/dB, dL/dW0 intentionally zero.

    Assumes upstream is dL/dy; verifies shape before computation.
    """
    if not a or not b or not x or not upstream:
        raise ValueError('empty LoRA')
    r=len(a)
    if any(len(row)!=len(x) for row in a) or len(b)!=len(upstream) or any(len(row)!=r for row in b):
        raise ValueError('LoRA gradient shape')
    if r > min(len(x),len(upstream)) or not math.isfinite(alpha):
        raise ValueError('LoRA rank or alpha')
    scale=alpha/r
    u=[dot(row,x) for row in a]
    db=tuple(tuple(scale*upstream[i]*u[k] for k in range(r)) for i in range(len(upstream)))
    du=[scale*sum(b[i][k]*upstream[i] for i in range(len(upstream))) for k in range(r)]
    da=tuple(tuple(du[k]*x[j] for j in range(len(x))) for k in range(r))
    return da, db

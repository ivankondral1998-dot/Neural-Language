#include "neural_runtime.hpp"
#include "mobile_plan.hpp"
#include <exception>
static bool nl_mobile_try(neural::Model& m){
if(m.graph||m.layers.size()!=3||m.ninput!=5)return false;
if(m.layers[0].in!=5||m.layers[0].out!=7||m.layers[0].type!=1||m.layers[0].storage!=1||m.layers[0].disabled!=0)return false;
if(m.layers[1].in!=7||m.layers[1].out!=3||m.layers[1].type!=2||m.layers[1].storage!=0||m.layers[1].disabled!=0)return false;
if(m.layers[2].in!=3||m.layers[2].out!=2||m.layers[2].type!=0||m.layers[2].storage!=1||m.layers[2].disabled!=0)return false;
if((int)m.z[0].size()!=7){m.z[0].assign(7,0);m.a[0].assign(7,0);}
neural::mobile_dense_int8_ilp4<5,7,1>(m.layers[0].q.data(),m.layers[0].b.data(),m.input.data(),m.z[0].data(),m.a[0].data(),m.layers[0].scale);
if((int)m.z[1].size()!=3){m.z[1].assign(3,0);m.a[1].assign(3,0);}
neural::mobile_dense_ilp4<7,3,2>(m.layers[1].w.data(),m.layers[1].b.data(),m.a[0].data(),m.z[1].data(),m.a[1].data());
if((int)m.z[2].size()!=2){m.z[2].assign(2,0);m.a[2].assign(2,0);}
neural::mobile_dense_int8_ilp4<3,2,0>(m.layers[2].q.data(),m.layers[2].b.data(),m.a[1].data(),m.z[2].data(),m.a[2].data(),m.layers[2].scale);
return true;
}
int main() {
try {
neural::Model brain("PackedSensor",5);
brain.layer("hidden",7,1,static_cast<uint32_t>(11ULL+0*31337ULL),1);
brain.layer("middle",3,2,static_cast<uint32_t>(11ULL+1*31337ULL),0);
brain.layer("out",2,0,static_cast<uint32_t>(11ULL+2*31337ULL),1);
brain.mobile_forward=&nl_mobile_try;
brain.mode=neural::Model::FULL;
brain.observe(std::vector<double>{0.25,-0.5,0.10000000000000001,0.29999999999999999,-0.20000000000000001});
brain.infer();
brain.gate("hidden",1,0,false);
brain.infer();
brain.gate("hidden",1,0,true);
brain.infer();
brain.report("packed_sensor.json");
return 0;
} catch(const std::exception& e) {std::cerr<<"NEURAL ERROR: "<<e.what()<<"\n";return 1;}
}

Same-device comparison; no weights updated. Requires Python3 and C++17 compiler.
Run: python run_compare.py --compiler clang++ --output results_NEW
If binaries/ exists: python run_compare.py --prebuilt --output results_NEW
Run on ARM64 Android from a private executable directory (e.g. Termux home), not shared Download storage.
For packed INT8 comparison run ./binaries/int8 2048 9 (when bundled).
Actual compiled .nir mixed-storage/fallback example: ./binaries/packed-demo
Output directory must be new. Keep environment.json and all paired logs.
INT8: clang++ -std=c++17 -O3 -ffp-contract=off -Iafter bench_int8.cpp -o bench_int8
./bench_int8
No phone results or universal language speed advantage are asserted.
